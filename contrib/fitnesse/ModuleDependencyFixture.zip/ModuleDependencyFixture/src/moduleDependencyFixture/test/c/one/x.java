package moduleDependencyFixture.test.c.one;

public class x {
  private moduleDependencyFixture.test.c.two.x c2;
}
