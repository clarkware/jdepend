package moduleDependencyFixture.test.c;

public class x {
}
