package moduleDependencyFixture.test.c.two;

public class x {
}
