package moduleDependencyFixture.test.a;

public class x {
  private moduleDependencyFixture.test.b.x b;
}
