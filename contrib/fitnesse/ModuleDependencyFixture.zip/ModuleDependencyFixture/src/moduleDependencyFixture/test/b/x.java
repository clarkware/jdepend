package moduleDependencyFixture.test.b;

public class x {
  private moduleDependencyFixture.test.c.one.x c1;
}
