package b;

public class x {
  private a.x a;
  private d.x d;
}
