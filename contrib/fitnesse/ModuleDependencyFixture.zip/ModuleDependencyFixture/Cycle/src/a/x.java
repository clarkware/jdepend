package a;

public class x {
  private b.x b;
}
