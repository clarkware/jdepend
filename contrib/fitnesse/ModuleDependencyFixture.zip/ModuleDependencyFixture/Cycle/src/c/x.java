package c;

public class x {
  private a.x a;
}
