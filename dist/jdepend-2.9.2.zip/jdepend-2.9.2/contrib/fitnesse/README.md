# FitNesse Module Dependency Fixture

Bob Martin contributed the Module Dependency Fixture
(`ModuleDependencyFixture.zip`) for FitNesse.

For details on how to use it, see
[Using the JDepend Fixture for FitNesse](http://www.butunclebob.com/ArticleS.UncleBob.JdependFixture).
