package jdepend.framework.p2;

public enum ExampleEnum {
	E1,
	E2
}
