package jdepend.framework.p1;

public @interface ExampleInnerAnnotation {

	Class<?>[] value() default {};
	
}
